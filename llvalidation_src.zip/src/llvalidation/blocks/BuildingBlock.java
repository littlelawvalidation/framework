package llvalidation.blocks;

import java.util.List;

public abstract class BuildingBlock {

	String txn;
	double r;
	double x;
	double z;
	int    c;
	int    e;
	List <BuildingBlock> children;
	
	public String getTxn() {
		return txn;
	}
	
	public void setTxn(String txn) {
		this.txn = txn;
	}
	
	public double getR() {
		return r;
	}
	
	public void setR(double r) {
		this.r = r;
	}
	
	public double getX() {
		return x;
	}
	
	public void setX(double x) {
		this.x = x;
	}
	
	public double getZ() {
		return z;
	}
	
	public void setZ(double z) {
		this.z = z;
	}
	
	public int getC() {
		return c;
	}
	
	public void setC(int c) {
		this.c = c;
	}
	
	public int getE() {
		return e;
	}
	
	public void setE(int e) {
		this.e = e;
	}
	
	public List<BuildingBlock> getChildren() {
		return children;
	}
	
	public int getNumberOfChildren() {
		return this.children.size();
	}
	
	public boolean hasChildren() {
		if (children.size() > 0) 
			return true;
		return false;
	}
	
	public void addChild(BuildingBlock child) {
		children.add(child);
	}
	
	public abstract void aggregate();
}
