package llvalidation.blocks;

import java.util.ArrayList;
import java.util.Iterator;

public class ConditionalBuildingBlock extends BuildingBlock {

	public ConditionalBuildingBlock(String txn) {
		this.txn      = txn;
		this.children = new ArrayList<BuildingBlock>();
	}

	public void aggregate() {
		int total = 0;
		Iterator<BuildingBlock> iterator = children.iterator();
		
		while (iterator.hasNext()) {
			BuildingBlock bb = (BuildingBlock)iterator.next();
			bb.aggregate();
		}
		
		iterator = children.iterator();
		while (iterator.hasNext()) {
			BuildingBlock bb = (BuildingBlock)iterator.next();
			total = total + bb.getE();
		}
		
		iterator = children.iterator();
		while (iterator.hasNext()) {
			BuildingBlock bb = (BuildingBlock)iterator.next();
			double p = bb.getE() * 1.0 / total * 1.0;
			x = x + bb.getX();
			e = e + bb.getE();
			r = r + p * bb.getR();
			z = z + p * bb.getZ();
		}
		
		c = 1;
		
		System.out.println("ConditionalBuildingBlock: " + txn + "r/z/x/e/c: " + r + "/" + 
				z + "/" + x + "/" + e + "/" + c);
	}

}