package llvalidation.blocks;

import java.util.ArrayList;
import java.util.Iterator;

public class LoopBuildingBlock extends BuildingBlock {

	int loop;
	
	public LoopBuildingBlock(String txn, int loop) {
		this.txn      = txn;
		this.children = new ArrayList<BuildingBlock>();
		this.loop     = loop;
	}

	public void aggregate() {
		Iterator<BuildingBlock> iterator = children.iterator();
		
		while (iterator.hasNext()) {
			BuildingBlock bb = (BuildingBlock)iterator.next();
			bb.aggregate();
		}
		
		iterator = children.iterator();
		while (iterator.hasNext()) {
			BuildingBlock bb = (BuildingBlock)iterator.next();
			x = x + bb.getX();
			e = e + bb.getE();
			r = loop * bb.getR();
			z = loop * bb.getZ();
		}
		
		c = loop;
		
		System.out.println("LoopBuildingBlock: " + txn + "r/z/x/e/c: " + r + "/" + 
				z + "/" + x + "/" + e + "/" + c);
		}
}
