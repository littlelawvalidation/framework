package llvalidation.blocks;

import java.util.ArrayList;
import java.util.Iterator;

public class SequenceBuildingBlock extends BuildingBlock {

	public SequenceBuildingBlock(String txn) {
		this.txn      = txn;
		this.children = new ArrayList<BuildingBlock>();
	}

	public void aggregate() {
		Iterator<BuildingBlock> iterator = children.iterator();
		
		while (iterator.hasNext()) {
			BuildingBlock bb = (BuildingBlock)iterator.next();
			bb.aggregate();
		}
		
		iterator = children.iterator();
		while (iterator.hasNext()) {
			BuildingBlock bb = (BuildingBlock)iterator.next();
			x = x + bb.getX();
			e = e + bb.getE();
			r = r + bb.getR();
			z = z + bb.getZ();
			c = c + bb.getC();
		}
		
		System.out.println("SequenceBuildingBlock: " + txn + "r/z/x/e/c: " + r + "/" + 
				z + "/" + x + "/" + e + "/" + c);
	}

}
