package llvalidation.blocks;

public class SingularBuildingBlock extends BuildingBlock {

	public SingularBuildingBlock(String txn, double r, double x, double z, int e) {
		this.txn = txn;
		this.r   = r;
		this.x   = x;
		this.z   = z;
		this.e   = e;
		this.c   = 1;
	}
	
	public void aggregate() {
		System.out.println("SingularBuildingBlock: " + txn + "r/z/x/e/c: " + r + "/" + 
		z + "/" + x + "/" + e + "/" + c);		
	}


}
