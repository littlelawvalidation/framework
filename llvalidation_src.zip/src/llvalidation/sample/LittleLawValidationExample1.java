package llvalidation.sample;

import java.text.DecimalFormat;

import llvalidation.blocks.ConditionalBuildingBlock;
import llvalidation.blocks.LoopBuildingBlock;
import llvalidation.blocks.SequenceBuildingBlock;
import llvalidation.blocks.SingularBuildingBlock;

public class LittleLawValidationExample1 {

	public static void main(String[] args) {

		SingularBuildingBlock sibb1 = new SingularBuildingBlock("homepage", 75, 12.8153, 0, 46253);
		SingularBuildingBlock sibb2 = new SingularBuildingBlock("login", 111, 10.2508, 0, 36985);
		SingularBuildingBlock sibb3 = new SingularBuildingBlock("newcustomer", 153, 2.5690, 0, 9268);		
		SingularBuildingBlock sibb4 = new SingularBuildingBlock("browse(category)", 85, 12.9234, 0, 46588);
		SingularBuildingBlock sibb5 = new SingularBuildingBlock("browse(actor)", 85, 12.8746, 0, 46414);
		SingularBuildingBlock sibb6 = new SingularBuildingBlock("browse(title)", 84, 12.8685, 0, 46391);
		SingularBuildingBlock sibb7 = new SingularBuildingBlock("purchase", 446, 12.8311, 3000, 46251);
		
		ConditionalBuildingBlock cnbb1 = new ConditionalBuildingBlock("cnbb1");
		cnbb1.addChild(sibb2);
		cnbb1.addChild(sibb3);
		
		ConditionalBuildingBlock cnbb2 = new ConditionalBuildingBlock("cnbb2");
		cnbb2.addChild(sibb4);
		cnbb2.addChild(sibb5);
		cnbb2.addChild(sibb6);

		LoopBuildingBlock lobb1 = new LoopBuildingBlock("lobb1", 3);
		lobb1.addChild(cnbb2);

		SequenceBuildingBlock sebb1 = new SequenceBuildingBlock("sebb1");
		sebb1.addChild(sibb1);
		sebb1.addChild(cnbb1);
		sebb1.addChild(lobb1);
		sebb1.addChild(sibb7);
		sebb1.aggregate();
		
		double xactual = sebb1.getX()/sebb1.getC();
		double xexpect = 50/((sebb1.getR() + sebb1.getZ())/1000);
		DecimalFormat f = new DecimalFormat("##.00");
		
		System.out.println("Xexpect:" + f.format(xexpect));
		System.out.println("Xactual:" + f.format(xactual));
		
	}

}
